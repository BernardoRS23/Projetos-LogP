﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppSimuladoProva_BernardoReis_2B1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //Pegar os dados
            float preco1 = float.Parse(txtPreco.Text);
            float preco2 = float.Parse(txtPreco2.Text);
            float preco3 = float.Parse(txtPreco3.Text);
            float valorCompra;

            //Calcular o valor da compra
            valorCompra = preco1 + preco2 + preco3;

            //Mostrar os resultados
            lblParcela1r.Text = (valorCompra / 1).ToString("C");
            lblParcela2r.Text = (valorCompra / 2).ToString("C");
            lblParcela3r.Text = (valorCompra / 3).ToString("C");
            lblParcela4r.Text = (valorCompra / 4).ToString("C");
            lblParcela5r.Text = (valorCompra / 5).ToString("C");
        }

        private void txtPreco_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
