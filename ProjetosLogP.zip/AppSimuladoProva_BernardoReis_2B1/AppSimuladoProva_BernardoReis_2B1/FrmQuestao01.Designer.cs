﻿namespace AppSimuladoProva_BernardoReis_2B1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlProdutos = new System.Windows.Forms.Panel();
            this.txtPreco3 = new System.Windows.Forms.TextBox();
            this.txtPreco2 = new System.Windows.Forms.TextBox();
            this.txtPreco = new System.Windows.Forms.TextBox();
            this.lblPreco2 = new System.Windows.Forms.Label();
            this.txtPreco1 = new System.Windows.Forms.Label();
            this.lblPreco3 = new System.Windows.Forms.Label();
            this.txtProduto3 = new System.Windows.Forms.TextBox();
            this.txtProduto2 = new System.Windows.Forms.TextBox();
            this.txtProduto1 = new System.Windows.Forms.TextBox();
            this.lblProduto2 = new System.Windows.Forms.Label();
            this.lblProduto1 = new System.Windows.Forms.Label();
            this.lblProduto3 = new System.Windows.Forms.Label();
            this.pnlLoja = new System.Windows.Forms.Panel();
            this.lblLoja = new System.Windows.Forms.Label();
            this.pnlParcelas = new System.Windows.Forms.Panel();
            this.lblParcela5r = new System.Windows.Forms.Label();
            this.lblParcela4r = new System.Windows.Forms.Label();
            this.lblParcela3r = new System.Windows.Forms.Label();
            this.lblParcela2r = new System.Windows.Forms.Label();
            this.lblParcela1r = new System.Windows.Forms.Label();
            this.lblParcela2 = new System.Windows.Forms.Label();
            this.lblParcela3 = new System.Windows.Forms.Label();
            this.lblParcela4 = new System.Windows.Forms.Label();
            this.lblParcela5 = new System.Windows.Forms.Label();
            this.lblParcela1 = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.pnlProdutos.SuspendLayout();
            this.pnlLoja.SuspendLayout();
            this.pnlParcelas.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlProdutos
            // 
            this.pnlProdutos.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pnlProdutos.Controls.Add(this.txtPreco3);
            this.pnlProdutos.Controls.Add(this.txtPreco2);
            this.pnlProdutos.Controls.Add(this.txtPreco);
            this.pnlProdutos.Controls.Add(this.lblPreco2);
            this.pnlProdutos.Controls.Add(this.txtPreco1);
            this.pnlProdutos.Controls.Add(this.lblPreco3);
            this.pnlProdutos.Controls.Add(this.txtProduto3);
            this.pnlProdutos.Controls.Add(this.txtProduto2);
            this.pnlProdutos.Controls.Add(this.txtProduto1);
            this.pnlProdutos.Controls.Add(this.lblProduto2);
            this.pnlProdutos.Controls.Add(this.lblProduto1);
            this.pnlProdutos.Controls.Add(this.lblProduto3);
            this.pnlProdutos.Location = new System.Drawing.Point(12, 148);
            this.pnlProdutos.Name = "pnlProdutos";
            this.pnlProdutos.Size = new System.Drawing.Size(438, 226);
            this.pnlProdutos.TabIndex = 2;
            // 
            // txtPreco3
            // 
            this.txtPreco3.Location = new System.Drawing.Point(260, 187);
            this.txtPreco3.Name = "txtPreco3";
            this.txtPreco3.Size = new System.Drawing.Size(100, 20);
            this.txtPreco3.TabIndex = 13;
            // 
            // txtPreco2
            // 
            this.txtPreco2.Location = new System.Drawing.Point(260, 116);
            this.txtPreco2.Name = "txtPreco2";
            this.txtPreco2.Size = new System.Drawing.Size(100, 20);
            this.txtPreco2.TabIndex = 12;
            // 
            // txtPreco
            // 
            this.txtPreco.Location = new System.Drawing.Point(260, 49);
            this.txtPreco.Name = "txtPreco";
            this.txtPreco.Size = new System.Drawing.Size(100, 20);
            this.txtPreco.TabIndex = 11;
            this.txtPreco.TextChanged += new System.EventHandler(this.txtPreco_TextChanged);
            // 
            // lblPreco2
            // 
            this.lblPreco2.AutoSize = true;
            this.lblPreco2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco2.Location = new System.Drawing.Point(255, 88);
            this.lblPreco2.Name = "lblPreco2";
            this.lblPreco2.Size = new System.Drawing.Size(80, 25);
            this.lblPreco2.TabIndex = 10;
            this.lblPreco2.Text = "Preço2";
            // 
            // txtPreco1
            // 
            this.txtPreco1.AutoSize = true;
            this.txtPreco1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPreco1.Location = new System.Drawing.Point(255, 21);
            this.txtPreco1.Name = "txtPreco1";
            this.txtPreco1.Size = new System.Drawing.Size(80, 25);
            this.txtPreco1.TabIndex = 9;
            this.txtPreco1.Text = "Preço1";
            // 
            // lblPreco3
            // 
            this.lblPreco3.AutoSize = true;
            this.lblPreco3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco3.Location = new System.Drawing.Point(255, 159);
            this.lblPreco3.Name = "lblPreco3";
            this.lblPreco3.Size = new System.Drawing.Size(80, 25);
            this.lblPreco3.TabIndex = 8;
            this.lblPreco3.Text = "Preço3";
            // 
            // txtProduto3
            // 
            this.txtProduto3.Location = new System.Drawing.Point(53, 187);
            this.txtProduto3.Name = "txtProduto3";
            this.txtProduto3.Size = new System.Drawing.Size(100, 20);
            this.txtProduto3.TabIndex = 7;
            // 
            // txtProduto2
            // 
            this.txtProduto2.Location = new System.Drawing.Point(53, 116);
            this.txtProduto2.Name = "txtProduto2";
            this.txtProduto2.Size = new System.Drawing.Size(100, 20);
            this.txtProduto2.TabIndex = 6;
            // 
            // txtProduto1
            // 
            this.txtProduto1.Location = new System.Drawing.Point(53, 49);
            this.txtProduto1.Name = "txtProduto1";
            this.txtProduto1.Size = new System.Drawing.Size(100, 20);
            this.txtProduto1.TabIndex = 5;
            // 
            // lblProduto2
            // 
            this.lblProduto2.AutoSize = true;
            this.lblProduto2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto2.Location = new System.Drawing.Point(48, 88);
            this.lblProduto2.Name = "lblProduto2";
            this.lblProduto2.Size = new System.Drawing.Size(99, 25);
            this.lblProduto2.TabIndex = 4;
            this.lblProduto2.Text = "Produto2";
            // 
            // lblProduto1
            // 
            this.lblProduto1.AutoSize = true;
            this.lblProduto1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto1.Location = new System.Drawing.Point(48, 21);
            this.lblProduto1.Name = "lblProduto1";
            this.lblProduto1.Size = new System.Drawing.Size(99, 25);
            this.lblProduto1.TabIndex = 3;
            this.lblProduto1.Text = "Produto1";
            // 
            // lblProduto3
            // 
            this.lblProduto3.AutoSize = true;
            this.lblProduto3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblProduto3.Location = new System.Drawing.Point(48, 159);
            this.lblProduto3.Name = "lblProduto3";
            this.lblProduto3.Size = new System.Drawing.Size(99, 25);
            this.lblProduto3.TabIndex = 2;
            this.lblProduto3.Text = "Produto3";
            this.lblProduto3.Click += new System.EventHandler(this.label4_Click);
            // 
            // pnlLoja
            // 
            this.pnlLoja.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pnlLoja.Controls.Add(this.lblLoja);
            this.pnlLoja.Location = new System.Drawing.Point(12, 12);
            this.pnlLoja.Name = "pnlLoja";
            this.pnlLoja.Size = new System.Drawing.Size(776, 130);
            this.pnlLoja.TabIndex = 3;
            // 
            // lblLoja
            // 
            this.lblLoja.AutoSize = true;
            this.lblLoja.Font = new System.Drawing.Font("Microsoft Sans Serif", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLoja.Location = new System.Drawing.Point(17, 29);
            this.lblLoja.Name = "lblLoja";
            this.lblLoja.Size = new System.Drawing.Size(480, 73);
            this.lblLoja.TabIndex = 0;
            this.lblLoja.Text = "Loja de Games";
            this.lblLoja.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // pnlParcelas
            // 
            this.pnlParcelas.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.pnlParcelas.Controls.Add(this.lblParcela5r);
            this.pnlParcelas.Controls.Add(this.lblParcela4r);
            this.pnlParcelas.Controls.Add(this.lblParcela3r);
            this.pnlParcelas.Controls.Add(this.lblParcela2r);
            this.pnlParcelas.Controls.Add(this.lblParcela1r);
            this.pnlParcelas.Controls.Add(this.lblParcela2);
            this.pnlParcelas.Controls.Add(this.lblParcela3);
            this.pnlParcelas.Controls.Add(this.lblParcela4);
            this.pnlParcelas.Controls.Add(this.lblParcela5);
            this.pnlParcelas.Controls.Add(this.lblParcela1);
            this.pnlParcelas.Location = new System.Drawing.Point(456, 149);
            this.pnlParcelas.Name = "pnlParcelas";
            this.pnlParcelas.Size = new System.Drawing.Size(330, 225);
            this.pnlParcelas.TabIndex = 4;
            // 
            // lblParcela5r
            // 
            this.lblParcela5r.AutoSize = true;
            this.lblParcela5r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela5r.Location = new System.Drawing.Point(181, 181);
            this.lblParcela5r.Name = "lblParcela5r";
            this.lblParcela5r.Size = new System.Drawing.Size(19, 25);
            this.lblParcela5r.TabIndex = 9;
            this.lblParcela5r.Text = "-";
            // 
            // lblParcela4r
            // 
            this.lblParcela4r.AutoSize = true;
            this.lblParcela4r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela4r.Location = new System.Drawing.Point(181, 143);
            this.lblParcela4r.Name = "lblParcela4r";
            this.lblParcela4r.Size = new System.Drawing.Size(19, 25);
            this.lblParcela4r.TabIndex = 8;
            this.lblParcela4r.Text = "-";
            // 
            // lblParcela3r
            // 
            this.lblParcela3r.AutoSize = true;
            this.lblParcela3r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela3r.Location = new System.Drawing.Point(181, 101);
            this.lblParcela3r.Name = "lblParcela3r";
            this.lblParcela3r.Size = new System.Drawing.Size(19, 25);
            this.lblParcela3r.TabIndex = 7;
            this.lblParcela3r.Text = "-";
            // 
            // lblParcela2r
            // 
            this.lblParcela2r.AutoSize = true;
            this.lblParcela2r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela2r.Location = new System.Drawing.Point(181, 61);
            this.lblParcela2r.Name = "lblParcela2r";
            this.lblParcela2r.Size = new System.Drawing.Size(19, 25);
            this.lblParcela2r.TabIndex = 6;
            this.lblParcela2r.Text = "-";
            // 
            // lblParcela1r
            // 
            this.lblParcela1r.AutoSize = true;
            this.lblParcela1r.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela1r.Location = new System.Drawing.Point(170, 21);
            this.lblParcela1r.Name = "lblParcela1r";
            this.lblParcela1r.Size = new System.Drawing.Size(19, 25);
            this.lblParcela1r.TabIndex = 5;
            this.lblParcela1r.Text = "-";
            // 
            // lblParcela2
            // 
            this.lblParcela2.AutoSize = true;
            this.lblParcela2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela2.Location = new System.Drawing.Point(29, 61);
            this.lblParcela2.Name = "lblParcela2";
            this.lblParcela2.Size = new System.Drawing.Size(160, 25);
            this.lblParcela2.TabIndex = 4;
            this.lblParcela2.Text = "02 parcelas de:";
            this.lblParcela2.Click += new System.EventHandler(this.label12_Click);
            // 
            // lblParcela3
            // 
            this.lblParcela3.AutoSize = true;
            this.lblParcela3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela3.Location = new System.Drawing.Point(29, 101);
            this.lblParcela3.Name = "lblParcela3";
            this.lblParcela3.Size = new System.Drawing.Size(160, 25);
            this.lblParcela3.TabIndex = 3;
            this.lblParcela3.Text = "03 parcelas de:";
            // 
            // lblParcela4
            // 
            this.lblParcela4.AutoSize = true;
            this.lblParcela4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela4.Location = new System.Drawing.Point(29, 143);
            this.lblParcela4.Name = "lblParcela4";
            this.lblParcela4.Size = new System.Drawing.Size(160, 25);
            this.lblParcela4.TabIndex = 2;
            this.lblParcela4.Text = "04 parcelas de:";
            // 
            // lblParcela5
            // 
            this.lblParcela5.AutoSize = true;
            this.lblParcela5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela5.Location = new System.Drawing.Point(29, 181);
            this.lblParcela5.Name = "lblParcela5";
            this.lblParcela5.Size = new System.Drawing.Size(160, 25);
            this.lblParcela5.TabIndex = 1;
            this.lblParcela5.Text = "05 parcelas de:";
            // 
            // lblParcela1
            // 
            this.lblParcela1.AutoSize = true;
            this.lblParcela1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblParcela1.Location = new System.Drawing.Point(29, 21);
            this.lblParcela1.Name = "lblParcela1";
            this.lblParcela1.Size = new System.Drawing.Size(149, 25);
            this.lblParcela1.TabIndex = 0;
            this.lblParcela1.Text = "01 parcela de:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.btnCalcular.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCalcular.Location = new System.Drawing.Point(12, 380);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(774, 49);
            this.btnCalcular.TabIndex = 5;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = false;
            this.btnCalcular.Click += new System.EventHandler(this.btnCalcular_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(800, 436);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.pnlParcelas);
            this.Controls.Add(this.pnlLoja);
            this.Controls.Add(this.pnlProdutos);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.pnlProdutos.ResumeLayout(false);
            this.pnlProdutos.PerformLayout();
            this.pnlLoja.ResumeLayout(false);
            this.pnlLoja.PerformLayout();
            this.pnlParcelas.ResumeLayout(false);
            this.pnlParcelas.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel pnlProdutos;
        private System.Windows.Forms.Label lblProduto3;
        private System.Windows.Forms.TextBox txtPreco3;
        private System.Windows.Forms.TextBox txtPreco2;
        private System.Windows.Forms.TextBox txtPreco;
        private System.Windows.Forms.Label lblPreco2;
        private System.Windows.Forms.Label txtPreco1;
        private System.Windows.Forms.Label lblPreco3;
        private System.Windows.Forms.TextBox txtProduto3;
        private System.Windows.Forms.TextBox txtProduto2;
        private System.Windows.Forms.TextBox txtProduto1;
        private System.Windows.Forms.Label lblProduto2;
        private System.Windows.Forms.Label lblProduto1;
        private System.Windows.Forms.Panel pnlLoja;
        private System.Windows.Forms.Label lblLoja;
        private System.Windows.Forms.Panel pnlParcelas;
        private System.Windows.Forms.Label lblParcela2;
        private System.Windows.Forms.Label lblParcela3;
        private System.Windows.Forms.Label lblParcela4;
        private System.Windows.Forms.Label lblParcela5;
        private System.Windows.Forms.Label lblParcela1;
        private System.Windows.Forms.Label lblParcela5r;
        private System.Windows.Forms.Label lblParcela4r;
        private System.Windows.Forms.Label lblParcela3r;
        private System.Windows.Forms.Label lblParcela2r;
        private System.Windows.Forms.Label lblParcela1r;
        private System.Windows.Forms.Button btnCalcular;
    }
}

