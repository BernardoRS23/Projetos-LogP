﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class FrmQuestao01 : Form
    {
        public FrmQuestao01()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int num1 = int.Parse(txtNum01);
            int num2 = int.Parse(txtNum02);
            int num3 = int.Parse(txtNum03);
            int Resultado;

            Resultado = num1 + num2 + num3;
            MessageBox.Show("Soma:" + Resultado);

        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNum01);
            int num2 = int.Parse(txtNum02);
            int num3 = int.Parse(txtNum03);
            float Resultado;

            Resultado = (num1 + num2 + num3) / 3;
            MessageBox.Show("Média:" + Resultado);

        }

        private void btnSomar_Click(object sender, EventArgs e)
        {
            int num1 = int.Parse(txtNum01);
            int num2 = int.Parse(txtNum02);
            int num3 = int.Parse(txtNum03);
            float Resultado;

            Resultado = num1 + num2 + num3;
            MessageBox.Show("Soma:" + Resultado);
        }
    }
}
